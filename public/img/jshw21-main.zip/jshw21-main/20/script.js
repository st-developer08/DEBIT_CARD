
let currentUser = {
    email: 'alexadams@google.com',
    firstName: 'Alex',
    lastName: 'Adams'
};


let wallets = [
    { id: 1, type: 'Visa', currency: 'RUB', color: '#e57373' },
    { id: 2, type: 'Visa', currency: 'RUB', color: '#9575cd' },
    { id: 3, type: 'Visa', currency: 'RUB', color: '#4db6ac' },
    { id: 4, type: 'Visa', currency: 'RUB', color: '#4dd0e1' }
];


let transactions = [
    {
        id: '123232',
        walletType: 'VISA',
        category: 'Автомобиль',
        amount: 414000000,
        date: '4 дня назад'
    }
];


function addWallet(name, currency) {
    const wallet = {
        id: wallets.length + 1,
        type: 'Visa',
        currency: currency,
        color: getRandomColor()
    };
    wallets.push(wallet);
    renderWallets();
}

function addTransaction(fromWallet, amount, category) {
    const transaction = {
        id: Date.now().toString(),
        walletType: fromWallet,
        category: category,
        amount: parseFloat(amount),
        date: '1 минуту назад'
    };
    transactions.unshift(transaction);
    renderTransactions();
}


function getRandomColor() {
    const colors = ['#e57373', '#9575cd', '#4db6ac', '#4dd0e1'];
    return colors[Math.floor(Math.random() * colors.length)];
}

function renderWallets() {
    const walletList = document.getElementById('walletList');
    walletList.innerHTML = '';
    wallets.forEach(wallet => {
        const li = document.createElement('li');
        li.textContent = `${wallet.type} (${wallet.currency})`;
        walletList.appendChild(li);
    });
}

function renderTransactions() {
    const transactionList = document.getElementById('transactionList');
    transactionList.innerHTML = '';
    transactions.forEach(transaction => {
        const li = document.createElement('li');
        li.textContent = `${transaction.category}: ${transaction.amount} (${transaction.date})`;
        transactionList.appendChild(li);
    });
}


document.addEventListener('DOMContentLoaded', () => {
    
    const walletForm = document.getElementById('addWalletForm');
    if (walletForm) {
        walletForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('walletName').value;
            const currency = document.getElementById('walletCurrency').value;
            addWallet(name, currency);
        });
    }

    const transactionForm = document.getElementById('addTransactionForm');
    if (transactionForm) {
        transactionForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const wallet = document.getElementById('transactionWallet').value;
            const amount = document.getElementById('transactionAmount').value;
            const category = document.getElementById('transactionCategory').value;
            addTransaction(wallet, amount, category);
        });
    }
});



function renderWallets() {
    const walletList = document.getElementById('walletsContainer');
    walletList.innerHTML = '';
    wallets.forEach(wallet => {
        const div = document.createElement('div');
        div.classList.add('wallet-card');
        div.style.background = wallet.color;
        div.textContent = `${wallet.type} (${wallet.currency})`;
        walletList.appendChild(div);

        // Добавим в select для транзакций
        const select = document.getElementById('transactionWallet');
        const option = document.createElement('option');
        option.value = wallet.type;
        option.textContent = wallet.type;
        select.appendChild(option);
    });
}

function renderTransactions() {
    const transactionList = document.getElementById('transactionsContainer');
    transactionList.innerHTML = '';
    transactions.forEach(transaction => {
        const row = document.createElement('div');
        row.classList.add('transaction-row');
        row.innerHTML = `
            <div>${transaction.walletType}</div>
            <div>${transaction.category}</div>
            <div>${transaction.amount}</div>
            <div>${transaction.date}</div>
        `;
        transactionList.appendChild(row);
    });
}


document.addEventListener('DOMContentLoaded', () => {
    renderWallets();
    renderTransactions();
    const addWalletForm = document.getElementById('addWalletForm');
    if (addWalletForm) {
        addWalletForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const name = document.getElementById('walletName').value;
            const currency = document.getElementById('walletCurrency').value;
            addWallet(name, currency);
        });
    }

    const addTransactionForm = document.getElementById('addTransactionForm');
    if (addTransactionForm) {
        addTransactionForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const wallet = document.getElementById('transactionWallet').value;
            const amount = document.getElementById('transactionAmount').value;
            const category = document.getElementById('transactionCategory').value;
            addTransaction(wallet, amount, category);
        });
    }ё
});
